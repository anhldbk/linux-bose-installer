var menudata={children:[
{text:"Main Page",url:"index.html"},
{text:"Data Structures",url:"annotated.html",children:[
{text:"Data Structures",url:"annotated.html"},
{text:"Data Fields",url:"functions.html",children:[
{text:"All",url:"functions.html"},
{text:"Variables",url:"functions_vars.html"}]}]},
{text:"Files",url:"files.html",children:[
{text:"File List",url:"files.html"},
{text:"Globals",url:"globals.html",children:[
{text:"All",url:"globals.html",children:[
{text:"b",url:"globals.html#index_b"},
{text:"f",url:"globals.html#index_f"},
{text:"j",url:"globals.html#index_j"},
{text:"o",url:"globals.html#index_o"},
{text:"p",url:"globals.html#index_p"},
{text:"r",url:"globals.html#index_r"},
{text:"s",url:"globals.html#index_s"}]},
{text:"Functions",url:"globals_func.html",children:[
{text:"b",url:"globals_func.html#index_b"},
{text:"f",url:"globals_func.html#index_f"},
{text:"o",url:"globals_func.html#index_o"},
{text:"p",url:"globals_func.html#index_p"},
{text:"r",url:"globals_func.html#index_r"},
{text:"s",url:"globals_func.html#index_s"}]},
{text:"Typedefs",url:"globals_type.html"},
{text:"Macros",url:"globals_defs.html"}]}]}]}
